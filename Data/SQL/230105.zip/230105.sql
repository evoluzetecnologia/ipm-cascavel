PRAGMA foreign_keys = 0;

CREATE TABLE sqlitestudio_temp_table AS SELECT *
                                          FROM ipm;

DROP TABLE ipm;

CREATE TABLE ipm (
    ID_PERFIL                  INTEGER     REFERENCES _perfil (ID_PERFIL),
    ID_CLIENTE                 INTEGER     REFERENCES cliente (ID_CLIENTE),
    LOGIN                      TEXT        DEFAULT ('Default'),
    PASSWORD                   TEXT        DEFAULT ('Default'),
    CODIGO_LOGIN               TEXT        DEFAULT ('Default'),
    CODIGO_TOMADOR             TEXT        DEFAULT ('Default'),
    CADASTRO_ECONOMICO         TEXT        DEFAULT ('Default'),
    DOWNLOAD_SAIDA             TEXT        DEFAULT ('Default'),
    DOWNLOAD_ENTRADA           TEXT        DEFAULT ('Default'),
    PROTOCOLAR_SAIDA           TEXT        DEFAULT ('Default'),
    PROTOCOLAR_ENTRADA         TEXT        DEFAULT ('Default'),
    DECLARAR_SIMPLES_NACIONAL  BOOLEAN     DEFAULT (True),
    LANCAR_NOTA_ENTRADA        BOOLEAN     DEFAULT (False),
    PERIODO_DOWNLOAD_SAIDA     VARCHAR (7) DEFAULT (''),
    PERIODO_PDF_SAIDA          VARCHAR (7) DEFAULT (''),
    PERIODO_DOWNLOAD_ENTRADA   VARCHAR (7) DEFAULT (''),
    PERIODO_PDF_ENTRADA        VARCHAR (7) DEFAULT (''),
    PERIODO_DECLARACAO_SAIDA   VARCHAR (7) DEFAULT (''),
    PERIODO_DECLARACAO_ENTRADA VARCHAR (7) DEFAULT (''),
    PERIODO_SIMPLES_NACIONAL   VARCHAR (7) DEFAULT (''),
    PERIODO_CANCELAMENTO       VARCHAR (7) DEFAULT (''),
    PERIODO_CERTIDAO           VARCHAR (7) DEFAULT (''),
    PERIODO_EXTRATO            VARCHAR (7) DEFAULT (''),
    TOTAL_SAIDA                INTEGER     DEFAULT (0),
    TOTAL_ENTRADA              INTEGER     DEFAULT (0),
    PRIMARY KEY (
        ID_PERFIL,
        ID_CLIENTE
    )
);

INSERT INTO ipm (
                    ID_PERFIL,
                    ID_CLIENTE,
                    LOGIN,
                    PASSWORD,
                    CODIGO_LOGIN,
                    CODIGO_TOMADOR,
                    CADASTRO_ECONOMICO,
                    DOWNLOAD_SAIDA,
                    DOWNLOAD_ENTRADA,
                    PROTOCOLAR_SAIDA,
                    PROTOCOLAR_ENTRADA,
                    DECLARAR_SIMPLES_NACIONAL,
                    LANCAR_NOTA_ENTRADA,
                    PERIODO_DOWNLOAD_SAIDA,
                    PERIODO_PDF_SAIDA,
                    PERIODO_DOWNLOAD_ENTRADA,
                    PERIODO_PDF_ENTRADA,
                    PERIODO_DECLARACAO_SAIDA,
                    PERIODO_DECLARACAO_ENTRADA,
                    PERIODO_SIMPLES_NACIONAL,
                    PERIODO_CERTIDAO,
                    PERIODO_EXTRATO,
                    TOTAL_SAIDA,
                    TOTAL_ENTRADA
                )
                SELECT ID_PERFIL,
                       ID_CLIENTE,
                       LOGIN,
                       PASSWORD,
                       CODIGO_LOGIN,
                       CODIGO_TOMADOR,
                       CADASTRO_ECONOMICO,
                       DOWNLOAD_SAIDA,
                       DOWNLOAD_ENTRADA,
                       PROTOCOLAR_SAIDA,
                       PROTOCOLAR_ENTRADA,
                       DECLARAR_SIMPLES_NACIONAL,
                       LANCAR_NOTA_ENTRADA,
                       PERIODO_DOWNLOAD_SAIDA,
                       PERIODO_PDF_SAIDA,
                       PERIODO_DOWNLOAD_ENTRADA,
                       PERIODO_PDF_ENTRADA,
                       PERIODO_DECLARACAO_SAIDA,
                       PERIODO_DECLARACAO_ENTRADA,
                       PERIODO_SIMPLES_NACIONAL,
                       PERIODO_CERTIDAO,
                       PERIODO_EXTRATO,
                       TOTAL_SAIDA,
                       TOTAL_ENTRADA
                  FROM sqlitestudio_temp_table;

DROP TABLE sqlitestudio_temp_table;

PRAGMA foreign_keys = 1;