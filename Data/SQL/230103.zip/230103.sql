PRAGMA foreign_keys = 0;

CREATE TABLE sqlitestudio_temp_table AS SELECT *
                                          FROM ipm;

DROP TABLE ipm;

CREATE TABLE ipm (
    ID_PERFIL                  INTEGER     REFERENCES _perfil (ID_PERFIL),
    ID_CLIENTE                 INTEGER     REFERENCES cliente (ID_CLIENTE),
    LOGIN                      TEXT,
    PASSWORD                   TEXT,
    CODIGO_LOGIN               TEXT,
    CODIGO_TOMADOR             TEXT,
    CADASTRO_ECONOMICO         TEXT,
    DOWNLOAD_SAIDA             TEXT,
    DOWNLOAD_ENTRADA           TEXT,
    PROTOCOLAR_SAIDA           TEXT,
    PROTOCOLAR_ENTRADA         TEXT,
    DECLARAR_SIMPLES_NACIONAL  BOOLEAN     DEFAULT (False),
    LANCAR_NOTA_ENTRADA        BOOLEAN     DEFAULT (False),
    PERIODO_DOWNLOAD_SAIDA     VARCHAR (7) DEFAULT (''),
    PERIODO_PDF_SAIDA          VARCHAR (7) DEFAULT (''),
    PERIODO_DOWNLOAD_ENTRADA   VARCHAR (7) DEFAULT (''),
    PERIODO_PDF_ENTRADA        VARCHAR (7) DEFAULT (''),
    PERIODO_DECLARACAO_SAIDA   VARCHAR (7) DEFAULT (''),
    PERIODO_DECLARACAO_ENTRADA VARCHAR (7) DEFAULT (''),
    PERIODO_SIMPLES_NACIONAL   VARCHAR (7) DEFAULT (''),
    PERIODO_CERTIDAO           VARCHAR (7) DEFAULT (''),
    PERIODO_EXTRATO            VARCHAR (7) DEFAULT (''),
    PRIMARY KEY (
        ID_PERFIL,
        ID_CLIENTE
    )
);

INSERT INTO ipm (
                    ID_PERFIL,
                    ID_CLIENTE,
                    LOGIN,
                    PASSWORD,
                    CODIGO_LOGIN,
                    CODIGO_TOMADOR,
                    CADASTRO_ECONOMICO,
                    DOWNLOAD_SAIDA,
                    DOWNLOAD_ENTRADA,
                    PROTOCOLAR_SAIDA,
                    PROTOCOLAR_ENTRADA,
                    DECLARAR_SIMPLES_NACIONAL,
                    LANCAR_NOTA_ENTRADA,
                    PERIODO_DOWNLOAD_SAIDA,
                    PERIODO_DOWNLOAD_ENTRADA,
                    PERIODO_DECLARACAO_SAIDA,
                    PERIODO_DECLARACAO_ENTRADA,
                    PERIODO_SIMPLES_NACIONAL,
                    PERIODO_CERTIDAO
                )
                SELECT ID_PERFIL,
                       ID_CLIENTE,
                       LOGIN,
                       PASSWORD,
                       CODIGO_LOGIN,
                       CODIGO_TOMADOR,
                       CADASTRO_ECONOMICO,
                       DOWNLOAD_SAIDA,
                       DOWNLOAD_ENTRADA,
                       PROTOCOLAR_SAIDA,
                       PROTOCOLAR_ENTRADA,
                       DECLARAR_SIMPLES_NACIONAL,
                       LANCAR_NOTA_ENTRADA,
                       PERIODO_DOWNLOAD_SAIDA,
                       PERIODO_DOWNLOAD_ENTRADA,
                       PERIODO_DECLARACAO_SAIDA,
                       PERIODO_DECLARACAO_ENTRADA,
                       PERIODO_SIMPLES_NACIONAL,
                       PERIODO_CERTIDAO
                  FROM sqlitestudio_temp_table;

DROP TABLE sqlitestudio_temp_table;

PRAGMA foreign_keys = 1;
